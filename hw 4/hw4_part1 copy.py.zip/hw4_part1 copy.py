#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 14:59:09 2019

@author: kaitlin
"""

def check_pass(password):
    length = len(password)
    password = password.split()
    first = password[0]
    if 10 <= length <= 25 and (first.isupper() or first.islower()):
        print('Rule 1 is satisfied')
    if ("@" in password or "$" in password) and ("%" not in password):
        print("Rule 2 is satisfied")
    




password = input("Enter a password => ")
print(password)